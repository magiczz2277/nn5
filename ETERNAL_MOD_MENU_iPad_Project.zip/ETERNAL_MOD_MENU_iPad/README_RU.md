# ETERNAL MOD MENU — iPad M2

Готовый исходный проект SwiftUI/Xcode для отдельного офлайн-приложения:
- неоновая панель управления;
- радар с искусственными тренировочными метками;
- локальная aim-training сцена (без управления сторонней игрой);
- косметический предпросмотр тем/скинов;
- настройка демонстрационного прицела.

**Это не чит и не подключается к играм.** Он не читает память игры, не показывает реальных игроков,
не меняет игровые скины и не автоматизирует управление в сторонних приложениях.

## Облачная сборка через Codemagic (Windows + iPad)

1. Распакуй архив на Windows.
2. Создай аккаунт на https://codemagic.io/ и добавь этот проект в Git-провайдер (например, GitHub).
3. В Codemagic открой Teams → Integrations → Developer Portal и добавь App Store Connect API key.
4. В `codemagic.yaml` замени `YOUR_APP_STORE_CONNECT_INTEGRATION` на имя интеграции в Codemagic.
5. Укажи уникальный Bundle ID вместо `com.example.eternalmodmenu` и используй тот же ID в настройке подписи.
6. В настройках приложения Apple Developer создай App ID с этим Bundle ID. В Codemagic настрой automatic signing / provisioning profile.
7. Запусти workflow `ios-ipa`. После успешной сборки скачай IPA из Artifacts.

## Важно про конфигурацию
Codemagic может потребовать согласовать метод экспорта IPA с выбранным способом распространения.
Для установки на зарегистрированные устройства используй Ad Hoc и добавь UDID iPad в профиль.
Для распространения через TestFlight/App Store используй App Store distribution; TestFlight требует загрузки билда в App Store Connect.
Не передавай никому пароль Apple ID, приватный ключ или API private key. Загружай секреты только в защищённые настройки Codemagic.

## Файлы
- `ETERNALModMenu.xcodeproj` — проект Xcode
- `ETERNALModMenu/` — SwiftUI исходники
- `codemagic.yaml` — пример workflow облачной сборки
