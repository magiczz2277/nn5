import SwiftUI

private let cyan = Color(red: 0.20, green: 0.88, blue: 1.00)
private let bg = Color(red: 0.025, green: 0.035, blue: 0.060)

struct MainView: View {
    @State private var selectedTab = 0
    @State private var showESP = true
    @State private var showNames = true
    @State private var aimAssist = 55.0
    @State private var markerCount = 5
    @State private var selectedSkin = 0
    @State private var crosshairSize = 18.0

    private let skins = [
        ("CYBER", Color.cyan, "Electric blue finish"),
        ("EMBER", Color.orange, "Warm orange finish"),
        ("VIOLET", Color.purple, "Neon violet finish"),
        ("TOXIC", Color.green, "Acid green finish")
    ]

    var body: some View {
        ZStack {
            bg.ignoresSafeArea()
            HStack(spacing: 0) {
                sidebar
                Rectangle().fill(cyan.opacity(0.13)).frame(width: 1)
                VStack(spacing: 0) {
                    header
                    Group {
                        switch selectedTab {
                        case 0: dashboard
                        case 1: training
                        case 2: skinsView
                        default: settings
                        }
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    footer
                }
                .padding(.horizontal, 26)
            }
        }
        .frame(minWidth: 700, minHeight: 450)
    }

    private var sidebar: some View {
        VStack(alignment: .leading, spacing: 26) {
            HStack(spacing: 11) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12).fill(cyan.opacity(0.13))
                    Image(systemName: "scope").font(.system(size: 24, weight: .bold)).foregroundStyle(cyan)
                }.frame(width: 48, height: 48)
                VStack(alignment: .leading, spacing: 3) {
                    Text("ETERNAL").font(.system(size: 18, weight: .black, design: .rounded)).tracking(1.5)
                    Text("TRAINING SUITE").font(.system(size: 9, weight: .bold, design: .monospaced)).tracking(1.8).foregroundStyle(cyan)
                }
            }
            VStack(alignment: .leading, spacing: 9) {
                navButton("Overview", icon: "square.grid.2x2.fill", tab: 0)
                navButton("Aim Lab", icon: "scope", tab: 1)
                navButton("Skin Preview", icon: "paintpalette.fill", tab: 2)
                navButton("Settings", icon: "slider.horizontal.3", tab: 3)
            }
            Spacer()
            VStack(alignment: .leading, spacing: 7) {
                Circle().fill(Color.green).frame(width: 7, height: 7)
                Text("LOCAL DEMO").font(.system(size: 10, weight: .bold, design: .monospaced)).foregroundStyle(.white.opacity(0.7))
                Text("No game connection").font(.system(size: 9, design: .monospaced)).foregroundStyle(.white.opacity(0.35))
            }
            .padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 12))
        }
        .padding(22)
        .frame(width: 220)
    }

    private func navButton(_ title: String, icon: String, tab: Int) -> some View {
        Button { selectedTab = tab } label: {
            HStack(spacing: 12) {
                Image(systemName: icon).frame(width: 19)
                Text(title).font(.system(size: 13, weight: .semibold))
                Spacer()
                if selectedTab == tab {
                    Circle().fill(cyan).frame(width: 5, height: 5)
                }
            }
            .foregroundStyle(selectedTab == tab ? cyan : .white.opacity(0.55))
            .padding(.horizontal, 13).padding(.vertical, 13)
            .background(selectedTab == tab ? cyan.opacity(0.10) : .clear,
                        in: RoundedRectangle(cornerRadius: 11))
            .overlay(RoundedRectangle(cornerRadius: 11)
                .stroke(selectedTab == tab ? cyan.opacity(0.25) : .clear, lineWidth: 1))
        }.buttonStyle(.plain)
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(["CONTROL CENTER", "AIM TRAINING LAB", "COSMETIC PREVIEW", "PREFERENCES"][selectedTab])
                    .font(.system(size: 19, weight: .black, design: .rounded)).tracking(1.2)
                Text("ETERNAL / IPAD EDITION").font(.system(size: 10, weight: .medium, design: .monospaced))
                    .foregroundStyle(.white.opacity(0.35)).tracking(1.4)
            }
            Spacer()
            HStack(spacing: 8) {
                Circle().fill(Color.green).frame(width: 6, height: 6)
                Text("DEMO READY").font(.system(size: 10, weight: .bold, design: .monospaced))
                    .foregroundStyle(.white.opacity(0.65))
            }
            .padding(.horizontal, 12).padding(.vertical, 9)
            .background(.white.opacity(0.045), in: Capsule())
        }
        .padding(.vertical, 23)
    }

    private var dashboard: some View {
        HStack(spacing: 18) {
            VStack(spacing: 18) {
                panel("RADAR SIMULATION", subtitle: "STATIC TRAINING TARGETS") {
                    RadarCanvas(count: markerCount, labels: showNames)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
                HStack(spacing: 12) {
                    statCard("TARGETS", value: "\(markerCount)", icon: "scope")
                    statCard("PROFILE", value: "CUSTOM", icon: "person.crop.circle")
                    statCard("MODE", value: "OFFLINE", icon: "wifi.slash")
                }
            }
            VStack(spacing: 18) {
                panel("VISUAL OVERLAY", subtitle: "LOCAL PREVIEW ONLY") {
                    VStack(alignment: .leading, spacing: 16) {
                        Toggle("Show demo boxes", isOn: $showESP).tint(cyan)
                        Toggle("Show target labels", isOn: $showNames).tint(cyan)
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Text("Marker quantity")
                                Spacer()
                                Text("\(markerCount)").foregroundStyle(cyan).monospacedDigit()
                            }.font(.system(size: 12, weight: .semibold))
                            Slider(value: Binding(get: { Double(markerCount) },
                                                  set: { markerCount = Int($0) }),
                                   in: 1...8, step: 1).tint(cyan)
                        }
                    }
                    .font(.system(size: 12))
                }
                panel("CROSSHAIR PREVIEW", subtitle: "COSMETIC ONLY") {
                    HStack {
                        Spacer()
                        Crosshair(size: crosshairSize, color: cyan).frame(width: 110, height: 90)
                        Spacer()
                        VStack(alignment: .leading, spacing: 7) {
                            Text("SIZE").font(.system(size: 9, weight: .bold, design: .monospaced)).foregroundStyle(.white.opacity(0.4))
                            Text("\(Int(crosshairSize)) px").font(.system(size: 17, weight: .bold, design: .rounded)).foregroundStyle(cyan)
                        }
                    }
                }
            }.frame(width: 280)
        }
    }

    private var training: some View {
        HStack(spacing: 20) {
            panel("AIM LAB", subtitle: "AIM PRACTICE SIMULATOR") {
                VStack(spacing: 14) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 14).fill(Color.black.opacity(0.35))
                        ForEach(0..<6, id: \.self) { i in
                            Circle().stroke(cyan.opacity(0.13), lineWidth: 1)
                                .frame(width: CGFloat(70 + i * 45), height: CGFloat(70 + i * 45))
                        }
                        TrainingTarget().frame(width: 86, height: 86)
                    }.frame(maxWidth: .infinity, maxHeight: .infinity)
                    Text("Tap the target in this standalone practice area.")
                        .font(.system(size: 11, design: .monospaced)).foregroundStyle(.white.opacity(0.45))
                }
            }
            .frame(maxWidth: .infinity)
            VStack(alignment: .leading, spacing: 20) {
                panel("PRACTICE SETTINGS", subtitle: "NO GAME INPUT") {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Tracking smoothness").font(.system(size: 12, weight: .semibold))
                        Slider(value: $aimAssist, in: 0...100).tint(cyan)
                        HStack { Text("LOW"); Spacer(); Text("\(Int(aimAssist))%").foregroundStyle(cyan); Spacer(); Text("HIGH") }
                            .font(.system(size: 9, weight: .bold, design: .monospaced)).foregroundStyle(.white.opacity(0.4))
                    }
                }
                Text("This is a self-contained visual trainer. It does not aim in, read, or control any third-party game.")
                    .font(.system(size: 11)).foregroundStyle(.white.opacity(0.42)).fixedSize(horizontal: false, vertical: true)
                Spacer()
            }.frame(width: 260)
        }
    }

    private var skinsView: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("Choose a visual theme for the demo item. These are local previews, not game inventory changes.")
                .font(.system(size: 12)).foregroundStyle(.white.opacity(0.45))
            HStack(spacing: 16) {
                ForEach(Array(skins.enumerated()), id: \.offset) { index, skin in
                    Button { selectedSkin = index } label: {
                        VStack(alignment: .leading, spacing: 12) {
                            ZStack {
                                RoundedRectangle(cornerRadius: 14).fill(skin.1.opacity(0.12))
                                Image(systemName: "bolt.fill").font(.system(size: 48)).foregroundStyle(skin.1)
                                    .shadow(color: skin.1.opacity(0.5), radius: 14)
                            }.frame(height: 150)
                            Text(skin.0).font(.system(size: 14, weight: .black, design: .rounded)).foregroundStyle(.white)
                            Text(skin.2).font(.system(size: 10)).foregroundStyle(.white.opacity(0.45))
                            if selectedSkin == index {
                                Label("SELECTED", systemImage: "checkmark.circle.fill")
                                    .font(.system(size: 9, weight: .bold, design: .monospaced)).foregroundStyle(cyan)
                            }
                        }
                        .padding(13).frame(maxWidth: .infinity, alignment: .leading)
                        .background(.white.opacity(selectedSkin == index ? 0.075 : 0.035), in: RoundedRectangle(cornerRadius: 17))
                        .overlay(RoundedRectangle(cornerRadius: 17).stroke(selectedSkin == index ? cyan.opacity(0.6) : .white.opacity(0.07), lineWidth: 1))
                    }.buttonStyle(.plain)
                }
            }
            Spacer()
        }.padding(.top, 8)
    }

    private var settings: some View {
        VStack(alignment: .leading, spacing: 20) {
            panel("INTERFACE", subtitle: "PERSONALIZE YOUR LOCAL APP") {
                VStack(alignment: .leading, spacing: 18) {
                    HStack {
                        Text("Crosshair size")
                        Spacer()
                        Text("\(Int(crosshairSize)) px").foregroundStyle(cyan).monospacedDigit()
                    }.font(.system(size: 13, weight: .semibold))
                    Slider(value: $crosshairSize, in: 8...32, step: 1).tint(cyan)
                    Toggle("Show demo boxes on overview", isOn: $showESP).tint(cyan)
                    Toggle("Show marker labels", isOn: $showNames).tint(cyan)
                }
            }.frame(maxWidth: 480)
            Text("Build: 1.0 • iPad landscape • Offline demo")
                .font(.system(size: 10, design: .monospaced)).foregroundStyle(.white.opacity(0.35))
            Spacer()
        }.padding(.top, 8)
    }

    private var footer: some View {
        HStack {
            Text("ETERNAL MOD MENU  /  VISUAL TRAINER")
            Spacer()
            Text("NOT CONNECTED TO ANY GAME")
        }
        .font(.system(size: 9, weight: .medium, design: .monospaced))
        .foregroundStyle(.white.opacity(0.28))
        .padding(.vertical, 14)
        .overlay(alignment: .top) { Rectangle().fill(.white.opacity(0.07)).frame(height: 1) }
    }

    private func panel<Content: View>(_ title: String, subtitle: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 13) {
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.system(size: 11, weight: .black, design: .rounded)).tracking(1.2).foregroundStyle(cyan)
                Text(subtitle).font(.system(size: 9, weight: .medium, design: .monospaced)).foregroundStyle(.white.opacity(0.32))
            }
            content()
        }
        .padding(17)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .background(.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 17))
        .overlay(RoundedRectangle(cornerRadius: 17).stroke(cyan.opacity(0.12), lineWidth: 1))
    }

    private func statCard(_ title: String, value: String, icon: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Image(systemName: icon).foregroundStyle(cyan)
            Text(value).font(.system(size: 15, weight: .black, design: .rounded))
            Text(title).font(.system(size: 8, weight: .bold, design: .monospaced)).foregroundStyle(.white.opacity(0.35))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(13).background(.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 13))
    }
}

struct RadarCanvas: View {
    let count: Int
    let labels: Bool
    private let spots: [CGPoint] = [
        .init(x: 0.50, y: 0.22), .init(x: 0.72, y: 0.38), .init(x: 0.29, y: 0.43),
        .init(x: 0.59, y: 0.68), .init(x: 0.22, y: 0.72), .init(x: 0.82, y: 0.73),
        .init(x: 0.43, y: 0.86), .init(x: 0.68, y: 0.16)
    ]
    var body: some View {
        GeometryReader { geo in
            let side = min(geo.size.width, geo.size.height) * 0.92
            ZStack {
                ForEach(1...3, id: \.self) { ring in
                    Circle().stroke(cyan.opacity(0.22), lineWidth: 1)
                        .frame(width: side * CGFloat(ring) / 3, height: side * CGFloat(ring) / 3)
                }
                Path { p in
                    p.move(to: CGPoint(x: geo.size.width/2, y: 0))
                    p.addLine(to: CGPoint(x: geo.size.width/2, y: geo.size.height))
                    p.move(to: CGPoint(x: 0, y: geo.size.height/2))
                    p.addLine(to: CGPoint(x: geo.size.width, y: geo.size.height/2))
                }.stroke(cyan.opacity(0.14), lineWidth: 1)
                Circle().fill(cyan).frame(width: 8, height: 8)
                ForEach(0..<count, id: \.self) { i in
                    VStack(spacing: 3) {
                        RoundedRectangle(cornerRadius: 3).stroke(Color.red, lineWidth: 1.5).frame(width: 22, height: 30)
                        if labels { Text("BOT \(i+1)").font(.system(size: 8, weight: .bold, design: .monospaced)).foregroundStyle(.white.opacity(0.65)) }
                    }
                    .position(x: (geo.size.width-side)/2 + side*spots[i].x,
                              y: (geo.size.height-side)/2 + side*spots[i].y)
                }
                Text("N").font(.system(size: 10, weight: .bold, design: .monospaced)).foregroundStyle(cyan)
                    .position(x: geo.size.width/2, y: 10)
            }.frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }
}

struct Crosshair: View {
    let size: Double
    let color: Color
    var body: some View {
        GeometryReader { geo in
            let c = CGPoint(x: geo.size.width/2, y: geo.size.height/2)
            ZStack {
                Circle().stroke(color.opacity(0.8), lineWidth: 1).frame(width: size*1.5, height: size*1.5)
                Path { p in
                    p.move(to: CGPoint(x: c.x, y: 0)); p.addLine(to: CGPoint(x: c.x, y: c.y-size))
                    p.move(to: CGPoint(x: c.x, y: c.y+size)); p.addLine(to: CGPoint(x: c.x, y: geo.size.height))
                    p.move(to: CGPoint(x: 0, y: c.y)); p.addLine(to: CGPoint(x: c.x-size, y: c.y))
                    p.move(to: CGPoint(x: c.x+size, y: c.y)); p.addLine(to: CGPoint(x: geo.size.width, y: c.y))
                }.stroke(color, lineWidth: 2)
                Circle().fill(color).frame(width: 4, height: 4)
            }
        }
    }
}

struct TrainingTarget: View {
    var body: some View {
        ZStack {
            Circle().stroke(cyan.opacity(0.35), lineWidth: 2)
            Circle().stroke(cyan.opacity(0.65), lineWidth: 2).padding(13)
            Circle().fill(cyan).frame(width: 9, height: 9)
            Image(systemName: "scope").font(.system(size: 23, weight: .light)).foregroundStyle(cyan)
        }
    }
}
